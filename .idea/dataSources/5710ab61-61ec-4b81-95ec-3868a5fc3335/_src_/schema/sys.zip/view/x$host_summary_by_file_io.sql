CREATE VIEW `x$host_summary_by_file_io` AS
  SELECT
    if(isnull(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`HOST`), 'background',
       `performance_schema`.`events_waits_summary_by_host_by_event_name`.`HOST`)            AS `host`,
    sum(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`COUNT_STAR`)     AS `ios`,
    sum(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`SUM_TIMER_WAIT`) AS `io_latency`
  FROM `performance_schema`.`events_waits_summary_by_host_by_event_name`
  WHERE (`performance_schema`.`events_waits_summary_by_host_by_event_name`.`EVENT_NAME` LIKE 'wait/io/file/%')
  GROUP BY if(isnull(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`HOST`), 'background',
              `performance_schema`.`events_waits_summary_by_host_by_event_name`.`HOST`)
  ORDER BY sum(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`SUM_TIMER_WAIT`) DESC;
